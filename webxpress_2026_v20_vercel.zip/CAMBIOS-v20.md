# WebXpress v20: migración de Netlify a Vercel
- Dominio cambiado a iwebxpress.vercel.app (canonical, OG, schema, sitemap, robots, llms.txt, demos y función de Stripe).
- `_headers` (Netlify) reemplazado por `vercel.json` con los mismos encabezados de seguridad (CSP, HSTS, etc.) y caché.
- `netlify/functions/checkout.js` movido a `api/checkout.js` (formato Vercel). Endpoint nuevo: `/api/checkout`. Variable opcional `SITE_URL` para el dominio de retorno de Stripe.
- Aviso de privacidad: proveedor de alojamiento ahora dice Vercel.
- Sin cambios: diseño, textos, demos, imágenes. El enlace a ai-optima.netlify.app (analizador) se dejó igual porque es otro sitio.
